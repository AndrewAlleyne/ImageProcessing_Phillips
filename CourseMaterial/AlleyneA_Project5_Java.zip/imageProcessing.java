import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class imageProcessing {

    int numRows;
    int numCols;
    int maxVal;
    int minVal;
    int newMinVal;
    int newMaxVal;
    int neigh[];


    imageProcessing(int numRows, int numCols, int minVal, int maxVal) {

        this.numRows = numRows;
        this.numCols = numCols;
        this.minVal = minVal;
        this.maxVal = maxVal;


        neigh = new int[10];


    }

    void setZero(int array[][]) {
        for (int i = 0; i < numRows + 2; i++) {
            for (int j = 0; j < numCols + 2; j++) {
                array[i][j] = 0;
            }
        }
    }

    void loadImage(Scanner scanner, int zeroFramedAry[][]) {
        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {
                if (scanner.hasNextInt()) zeroFramedAry[i][j] = scanner.nextInt();
            }
        }
    }

    void reformatPrettyPrint(int array[][], FileWriter of) throws IOException {
        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {
                int number = array[i][j];

                if (number == 0) {
                    of.write("  ");

                } else {
                    of.write(number + " ");

                }


            }
            of.write("\n");
        }
        of.flush();
        of.write("\n");
    }

    void compute8DistancePass1(int zeroFramedAry[][], FileWriter of) throws IOException {
        of.write("Results of 1st Distance Transform Pass:  \n");


        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {

                if (zeroFramedAry[i][j] > 0) {
                    zeroFramedAry[i][j] = neighborMin(zeroFramedAry, i, j, 1);
                }
            }
        }
        of.flush();
    }

    void compute8DistancePass2(int zeroFramedAry[][], FileWriter of) throws IOException {
        of.write("Results of 2nd Distance Transform Pass:  \n");

        for (int i = numRows; i >= 1; i--) {
            for (int j = numCols; j >= 1; j--) {

                if (zeroFramedAry[i][j] > 0) {
                    zeroFramedAry[i][j] = neighborMin(zeroFramedAry, i, j, 2);
                }
            }
        }
        of.flush();
    }

    int neighborMin(int zeroFramedAry[][], int i, int j, int pass) {
        int firstMin = 0;
        if (pass == 1) {
            neigh[0] = zeroFramedAry[i - 1][j - 1] + 1;
            neigh[1] = zeroFramedAry[i - 1][j] + 1;
            neigh[2] = zeroFramedAry[i - 1][j + 1] + 1;
            neigh[3] = zeroFramedAry[i][j - 1] + 1;
            firstMin = neigh[0];

            for (int k = 0; k < 4; k++) {

                if (firstMin > neigh[k]) {
                    firstMin = neigh[k];
                }
            }

        }

        if (pass == 2) {

            neigh[0] = zeroFramedAry[i + 1][j - 1] + 1;
            neigh[1] = zeroFramedAry[i + 1][j] + 1;
            neigh[2] = zeroFramedAry[i + 1][j + 1] + 1;
            neigh[3] = zeroFramedAry[i][j + 1] + 1;
            neigh[4] = zeroFramedAry[i][j];
            firstMin = neigh[0];
            for (int k = 0; k <= 4; k++) {
                if (firstMin > neigh[k]) firstMin = neigh[k];
            }


        }

        return firstMin;
    }

    void skeletonExtraction(int zeroFramedAry[][], int skeletonAry[][], FileWriter of) throws IOException {
        of.write("Results of Local Maxima: \n");

        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {
                if (zeroFramedAry[i][j] > 0) {
                    computeLocalMaxima(zeroFramedAry, skeletonAry, i, j);
                }
            }
        }


        of.flush();
    }

    void computeLocalMaxima(int zeroFramedAry[][], int skeletonAry[][], int i, int j) {


        neigh[0] = zeroFramedAry[i - 1][j - 1];
        neigh[1] = zeroFramedAry[i - 1][j];
        neigh[2] = zeroFramedAry[i - 1][j + 1];
        neigh[3] = zeroFramedAry[i][j - 1];
        neigh[4] = zeroFramedAry[i][j + 1];
        neigh[5] = zeroFramedAry[i + 1][j - 1];
        neigh[6] = zeroFramedAry[i + 1][j];
        neigh[7] = zeroFramedAry[i + 1][j + 1];

        int max = 0;
        for (int k = 0; k < 8; k++) {
            if (zeroFramedAry[i][j] >= neigh[k]) {
                max = zeroFramedAry[i][j];

            } else {
                max = 0;
                break;
            }

        }
        skeletonAry[i][j] = max;
    }

    void extractLocalMaxima(int skeletonAry[][], FileWriter of3) {
        try {


            of3.write("Results of Lossless compression: \n \n");
            of3.write(numRows + " " + numCols + " " + minVal + " " + maxVal + "\n");
            of3.write("\n");

            int max = skeletonAry[0][0];

            for (int i = 1; i <= numRows; i++) {
                for (int j = 1; j <= numCols; j++) {
                    if (skeletonAry[i][j] > 0) {
                        of3.write((i) + " " + (j) + " " + skeletonAry[i][j] + "\n");

                        if (skeletonAry[i][j] > max) {
                            max = skeletonAry[i][j];
                        }
                    }
                }
            }


            newMaxVal = max;


            of3.flush();
        } catch (IOException e) {
            System.out.println("Could not extract local maxima!");
            e.printStackTrace();

        }
    }

    void load(Scanner sScanner, int zeroFramedAry[][]) {
        if (sScanner.hasNextLine()) {
            sScanner.nextLine();
        }

        if (sScanner.hasNextInt()) numRows = sScanner.nextInt();
        if (sScanner.hasNextInt()) numCols = sScanner.nextInt();
        if (sScanner.hasNextInt()) minVal = sScanner.nextInt();
        if (sScanner.hasNextInt()) maxVal = sScanner.nextInt();

        int Lc_rows = 0;
        int Lc_cols = 0;
        int Lc_value = 0;


        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {

                if (sScanner.hasNextInt()) Lc_rows = sScanner.nextInt();
                if (sScanner.hasNextInt()) Lc_cols = sScanner.nextInt();
                if (sScanner.hasNextInt()) Lc_value = sScanner.nextInt();

                zeroFramedAry[Lc_rows][Lc_cols] = Lc_value;

            }
        }
    }

    void skeletonExpansionPass1(int zeroFramedAry[][], FileWriter of2) throws IOException {
        of2.write("Results of 1st Expansion pass: \n");
        of2.write("\n");

        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {
                if (zeroFramedAry[i][j] == 0) {
                    getMax(zeroFramedAry, i, j);
                }
            }
        }
    }

    void getMax(int zeroFramedAry[][], int i, int j) {

        neigh[0] = zeroFramedAry[i - 1][j - 1] - 1;
        neigh[1] = zeroFramedAry[i - 1][j] - 1;
        neigh[2] = zeroFramedAry[i - 1][j + 1] - 1;
        neigh[3] = zeroFramedAry[i][j - 1] - 1;
        neigh[4] = zeroFramedAry[i][j + 1] - 1;
        neigh[5] = zeroFramedAry[i + 1][j - 1] - 1;
        neigh[6] = zeroFramedAry[i + 1][j] - 1;
        neigh[7] = zeroFramedAry[i + 1][j + 1] - 1;

        int max;

        for (int k = 0; k < 8; k++) {
            max = neigh[k];

            if (zeroFramedAry[i][j] < max) {
                zeroFramedAry[i][j] = max;
            }
        }
    }

    void skeletonExpansionPass2(int zeroFramedAry[][], FileWriter of2) throws IOException {
        of2.write("Results of 2nd Expansion pass: \n");


        for (int i = numRows; i >= 1; i--) {
            for (int j = numCols; j >= 1; j--) {
                getMax2(zeroFramedAry, i, j);

            }
        }


        newMinVal = zeroFramedAry[0][0];
        newMaxVal = zeroFramedAry[0][0];

        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {


                if (zeroFramedAry[i][j] > newMaxVal) {
                    newMaxVal = zeroFramedAry[i][j];
                } else {
                    newMinVal = zeroFramedAry[i][j];
                }
            }
        }

        of2.write(numRows + " " + numCols + " " + newMinVal + " " + newMaxVal + "\n");


    }

    void getMax2(int zeroFramedAry[][], int i, int j) {

        neigh[0] = zeroFramedAry[i - 1][j - 1];
        neigh[1] = zeroFramedAry[i - 1][j];
        neigh[2] = zeroFramedAry[i - 1][j + 1];
        neigh[3] = zeroFramedAry[i][j - 1];
        neigh[4] = zeroFramedAry[i][j + 1];
        neigh[5] = zeroFramedAry[i + 1][j - 1];
        neigh[6] = zeroFramedAry[i + 1][j];
        neigh[7] = zeroFramedAry[i + 1][j + 1];

        int max;


        for (int k = 0; k < 8; k++) {
            max = neigh[k];

            if (zeroFramedAry[i][j] < max) {
                zeroFramedAry[i][j] = Math.abs(max - 1);
            }

        }
    }

    void thresholdDecompression(int array[][], FileWriter of) throws IOException {
        of.write("Results of Threshold Decompression: \n\n");
        of.write(numRows + " " + numCols + " " + minVal + " " + maxVal + "\n");


        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {

                if (array[i][j] >= 1) {
                    of.write("1 ");
                } else {
                    of.write("0 ");
                }


            }
            of.write("\n");
        }

        of.write("\n");
        of.flush();
    }


}
