/*
Andrew Alleyne
Project 5 - Image Compression via Distance Transform

*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        if (args.length < 3) {
            System.out.println("Provide more arguments");
        }

        String image = args[0];
        String outFile1 = args[1];
        String outFile2 = args[2];
        String skeletonFile = args[3] + "_skeleton.txt";
        String decompressFile = args[4] + "_decompressed.txt";

        int zeroFramedAry[][];
        int skeletonAry[][];

        int numRows = 0;
        int numCols = 0;
        int maxVal = 0;
        int minVal = 0;

        FileWriter of;
        FileWriter of2;
        FileWriter of3;
        FileWriter of4;

        Scanner scanner;
        Scanner sScanner;


        try {

            /*Does not work if you already have a named file in your directory. These files must be created
             * at the same time. */
            File sf = new File(skeletonFile);
            File df = new File(decompressFile);


            if (sf.createNewFile() && df.createNewFile()) {
                System.out.println(sf.getName() + " has been created!");
                System.out.println(df.getName() + " has been created!");
            } else {
                System.out.println(sf.getName() + " may already exist!");
                System.out.println(df.getName() + " may already exist!");

            }


            File file = new File(image);
            File sFile = new File(skeletonFile);

            scanner = new Scanner(file);
            sScanner = new Scanner(sFile);

            if (scanner.hasNextInt()) numRows = scanner.nextInt();
            if (scanner.hasNextInt()) numCols = scanner.nextInt();
            if (scanner.hasNextInt()) minVal = scanner.nextInt();
            if (scanner.hasNextInt()) maxVal = scanner.nextInt();


            of = new FileWriter(outFile1);
            of2 = new FileWriter(outFile2);
            of3 = new FileWriter(skeletonFile);
            of4 = new FileWriter(decompressFile);


            zeroFramedAry = new int[numRows + 2][numCols + 2];
            skeletonAry = new int[numRows + 2][numCols + 2];


            imageProcessing ip = new imageProcessing(numRows, numCols, minVal, maxVal);


            //Zero frame array to preform operations on binary image
            ip.setZero(zeroFramedAry);
            ip.setZero(skeletonAry);
            ip.loadImage(scanner, zeroFramedAry);

            ip.compute8DistancePass1(zeroFramedAry, of);
            ip.reformatPrettyPrint(zeroFramedAry, of);

            ip.compute8DistancePass2(zeroFramedAry, of);
            ip.reformatPrettyPrint(zeroFramedAry, of);


            ip.skeletonExtraction(zeroFramedAry, skeletonAry, of);
            ip.reformatPrettyPrint(skeletonAry, of);
            ip.extractLocalMaxima(skeletonAry, of3);


            ip.setZero(zeroFramedAry);
            ip.load(sScanner, zeroFramedAry);

            ip.skeletonExpansionPass1(zeroFramedAry, of2);
            ip.reformatPrettyPrint(zeroFramedAry, of2);

            ip.skeletonExpansionPass2(zeroFramedAry, of2);
            ip.reformatPrettyPrint(zeroFramedAry, of2);


            //ary2File (zeroFramedAry, decompressFile)
            ip.thresholdDecompression(zeroFramedAry, of4);

            of.close();
            of2.close();
            of3.close();
            of4.close();

        } catch (FileNotFoundException e) {
            System.out.println("Could not find the specified file!");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Failed I/O operation!");
            e.printStackTrace();
        }
    }
}
