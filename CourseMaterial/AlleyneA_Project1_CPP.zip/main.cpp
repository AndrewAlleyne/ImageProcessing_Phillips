/* Andrew Alleyne
CS 381/780 : Computer Vision Project 1
Queens College SP 21
 */

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <bits/stdc++.h>
using namespace std;

class Image
{
private:
  int numRows;
  int numCols;
  int minVal;
  int maxVal;
  int *histAry;
  int thresholdValue;

public:
  string inputFile;
  ifstream input;

  string line;
  string histogramHeader;

  vector<string> tokens;

  ofstream myOutputFile;
  string outputData;

  ofstream myOutputFile2;
  string outputData2;

  ofstream myOutputFile3;
  string outputData3;

public:
  Image(string inputFile, int thresholdValue, string outputData, string outputData2)
  {

    //Open input file to get headers
    input.open(inputFile);

    getline(input, line, '\n');

    histogramHeader = line;

    //Open output file for later use
    myOutputFile.open(outputData);

    //Open output file for later use
    myOutputFile2.open(outputData2);

    //Tokenize string
    stringstream check1(line);
    while (getline(check1, line, ' '))
    {
      tokens.push_back(line);
    }

    numRows = stoi(tokens[0]);
    numCols = stoi(tokens[1]);
    minVal = stoi(tokens[2]);
    maxVal = stoi(tokens[3]);

    //Dynamically allocate and initialize 1-D array
    histAry = new int[maxVal + 1];

    for (int i = 0; i < maxVal; i++)
    {
      histAry[i] = 0;
    }
  }

  void computeHistogram()
  {
    int pixel;

    while (input >> pixel)
    {
      histAry[pixel]++;
    }
    input.close();
  }

  void printHistogram()
  {
    myOutputFile << histogramHeader << endl;
    for (int i = 0; i <= maxVal; i++)
    {
      myOutputFile << i << " " << histAry[i] << "";
      myOutputFile << endl;
    }
    myOutputFile.close();
  }

  void displayHist()
  {
    myOutputFile2 << histogramHeader << endl;
    for (int i = 0; i <= maxVal; i++)
    {
      int pixValRep = 0;

      myOutputFile2 << i << " " << histAry[i] << " ";
      /* Use the maximum of 70 +’s for all counts greater than 70. Use small font
      size so that 70 +'s can be printed on one text line. */
      while (pixValRep != histAry[i] && pixValRep <= 70)
      {
        myOutputFile2 << "+";
        pixValRep++;
      }
      myOutputFile2 << endl;
    }
    myOutputFile2.close();
  }

  void threshold(ifstream &inputFile, ofstream &outputFile3, ofstream &outputFile4, int thresholdValue)
  {
    string line2;
    int line3;
    getline(inputFile, line2, '\n');

    //Header for Binary Threshold Operation - !FIXME BEFORE NEXT ASSIGNEMNT
    outputFile3 << numRows << " " << numCols << " " << 0 << " " << 1 << endl;
    outputFile4 << numRows << " " << numCols << " " << 0 << " " << 1 << endl;

    if (inputFile.is_open() && outputFile3.is_open() && outputFile4.is_open())
    {
      while (!inputFile.eof())
      {
        for (int y = 0; y < numRows; y++)
        {
          for (int x = 0; x < numCols; x++)
          {
            inputFile >> line3;

            if (line3 >= thresholdValue)
            {
              outputFile3 << 1 << " ";
              outputFile4 << 1 << " ";
            }
            else
            {
              outputFile3 << 0 << " ";
              outputFile4 << "."
                          << " ";
            }
          }
          outputFile3 << endl;
          outputFile4 << endl;
        }
      }
    }
  }
};

int main(int argc, char *argv[])
{
  /* 
  check argument count. 
  ./a.out, 
  data.txt, 
  Threshold values */

  if (argc < 7)
  {
    cout << "Missing arguments. It should look like "
         << "\"  inputFile ThresholdValue(int) outputFile1.txt ...... outputFile4.txt \"" << endl;
  }

  //Get input filename
  string inputFile = argv[1];

  //Get threshold
  int thresholdValue = atoi(argv[2]);

  string outputFile1 = argv[3];
  string outputFile2 = argv[4];

  //Iamge class
  Image
      image(inputFile, thresholdValue, outputFile1, outputFile2);
  image.computeHistogram();
  image.displayHist();
  image.printHistogram();

  //Reopen inputfile stream
  ifstream inputFileStream;
  inputFileStream.open(inputFile);

  string outputFile3 = argv[5];
  string outputFile4 = argv[6];

  ofstream outputFile3_Stream;
  outputFile3_Stream.open(outputFile3);

  ofstream outputFile4_Stream;
  outputFile4_Stream.open(outputFile4);

  image.threshold(inputFileStream, outputFile3_Stream, outputFile4_Stream, thresholdValue);

  return 0;
}