/* Andrew Alleyne
 * CS 381/780: Computer Vision
 * Project 3
 * Queens College SP 21
 *
 *
 * Project displays Morphological operations on images using
 * Dilation
 * Erosion
 * Opening
 * Closing
 */

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MMorph {

    int numImgRows;
    int numImgCols;
    int imgMin;
    int imgMax;
    int numStructRows;
    int numStructCols;
    int structMin;
    int structMax;
    int rowOrigin;
    int colOrigin;
    int rowFrameSize;
    int colsFrameSize;
    int extraRows;
    int extraCols;
    int[][] structAry;
    boolean isDiff = false;




    public MMorph(int numImgRows, int numImgCols, int imgMin,
                  int imgMax, int numStructRows, int numStructCols,
                  int structMin, int structMax, int rowOrigin,
                  int colOrigin, int rowFameSize, int colsFrameSize,
                  int extraRows, int extraCols, int[][] structAry) {

        this.numImgRows = numImgRows;
        this.numImgCols = numImgCols;
        this.imgMin = imgMin;
        this.imgMax = imgMax;
        this.numStructRows = numStructRows;
        this.numStructCols = numStructCols;
        this.structMin = structMin;
        this.structMax = structMax;
        this.rowOrigin = rowOrigin;
        this.colOrigin = colOrigin;
        this.rowFrameSize = rowFameSize;
        this.colsFrameSize = colsFrameSize;
        this.extraRows = extraRows;
        this.extraCols = extraCols;
        this.structAry = structAry;
    }

    //set  the given array to zero
    void zero2DAry(int[][] array, int rows, int cols) {

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                array[i][j] = 0;
            }
        }
    }

    //load image file into zeroFramedAry
    void loadImage(Scanner imgFile, int[][] array) {

        for (int i = 0; i < numImgRows; i++) {

            for (int j = 0; j < numImgCols; j++) {

                if (imgFile.hasNextInt()) {
                    array[rowOrigin + i][colOrigin + j] = imgFile.nextInt();
                }
            }
        }
    }

    // write a meaningful caption before prettyPrint
    void prettyPrint(int[][] array, FileWriter writer) throws IOException {

        if (array.length == 3) {
            writer.write(array.length + " " + array[0].length + " " + imgMin + " " + imgMax + "\n");
            writer.write("\n");

        } else {
            writer.write(array.length + " " + array[0].length + " " + imgMin + " " + imgMax + "\n");
            writer.write("\n");

        }

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[0].length; j++) {
                if (array[i][j] == 0) {

                    writer.write("." + " ");

                } else {
                    writer.write(1 + " ");
                }
            }
            writer.write("\n");
        }
        writer.write("\n");
        writer.flush();
    }
    /*
    load struct file into struct array
    @param structFile - Structuring File
    @param array - Structuring element Array
    */

    void loadstruct(Scanner structFile, int[][] array) {

        for (int i = 0; i < numStructRows; i++) {
            for (int j = 0; j < numStructCols; j++) {

                if (structFile.hasNextInt()) {
                    array[i][j] = structFile.nextInt();
                }
            }
        }

    }

    void ComputeDilation(int[][] zeroFrameAry, int[][] morphArray) {

        for (int i = rowFrameSize; i < rowFrameSize + numImgRows; i++) {
            for (int j = colsFrameSize; j < colsFrameSize + numImgCols; j++) {

                if (zeroFrameAry[i][j] > 0) {
                    dilation(i, j, zeroFrameAry, morphArray);
                }
            }
        }
    }

    /* Scan a 3x3 area of the image.
    * If if inAry[i,j] > 0 then according to Dilation: if any of the neighborhood pixels
    * is set to the value of 1, the output pixel is
    * set to 1.*/

    void dilation(int rFrame, int cFrame, int[][] zFrameAry, int[][] morphAry) {

        for (int k = 0; k < numStructRows; k++) {
            for (int m = 0; m < numStructCols; m++) {

                if (structAry[k][m] == 1) {
                    morphAry[rFrame - rowOrigin + k][cFrame - colOrigin + m] = 1;
                }
            }
        }
    }

    void AryToFile(int[][] morphAry, FileWriter writer) throws IOException {

        if (morphAry.length == 3) {
            writer.write("Structuring Element file pretty printed. \n" + morphAry.length + " " + morphAry[0].length + " " + imgMin + " " + imgMax + "\n");
        }
    }

    void ComputeErosion(int[][] zeroFrameAry, int[][] morphArray) {
        for (int i = rowFrameSize; i < rowFrameSize + numImgRows; i++) {
            for (int j = colsFrameSize; j < colsFrameSize + numImgCols; j++) {

                if (zeroFrameAry[i][j] > 0) {
                    erosion(i, j, zeroFrameAry, morphArray);
                }
            }
        }
    }
    /* Scan a 3x3 area of the image.
    * If inAry[i,j] > 0 surrounding the found value of 1.
    * If the elements in the first row do no match the elements in the
    * structuring elements first row we do not need them and output 0 and move onto the next cFrame index.
    * However if they match/true we move to the next rowOrigin and repeat the steps.
    *
    * Note: when a structure element contains zeros,
    * only those 1’s to be used in the matching of the erosion! */


    //erode doesn't match TAs results.
    void erosion(int rFrame, int cFrame, int[][] zFrameAry, int[][] morphAry) {

        //For tracing
        INNER_LOOP:
        OUTER_LOOP:

        for (int k =  0; k < numStructRows ; k++) {
            //if it doesnt match first row first col of struct we dont care about the 3X3 region. Terminate loop prematurely.
            for (int m = 0; m < numStructCols; m++) {
                if (zFrameAry[rFrame - rowOrigin + k][cFrame - colOrigin + m] != structAry[k][m] && structAry[k][m] == 1) {
                    morphAry[rFrame - rowOrigin + k][cFrame - colOrigin + m] = 0;
                    isDiff = true;
                    break INNER_LOOP;
                }
                isDiff = false;
            }
            //if they are different go back to cframe and increment
        if(isDiff)  break OUTER_LOOP;
        }
        if(!isDiff){
            morphAry[rFrame][cFrame] = 1;
        }
    }

    void ComputeOpening(int[][] zeroFrameAry,int[][] morphAry,int[][] tempAry) {
        ComputeErosion(zeroFrameAry,tempAry);
        ComputeDilation(tempAry,morphAry);
    }

    void ComputeClosing(int[][] zeroFrameAry,int[][] morphAry,int[][] tempAry) {
      ComputeDilation(zeroFrameAry,tempAry);
      ComputeErosion(tempAry,morphAry);


    }



}


