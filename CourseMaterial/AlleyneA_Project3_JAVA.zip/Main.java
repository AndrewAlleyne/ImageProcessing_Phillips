/* Andrew Alleyne
 * CS 381/780: Computer Vision
 * Project 3
 * Queens College SP 21
 *
 *
 * Project displays Morphological operations on images using
 * Dilation
 * Erosion
 * Opening
 * Closing
 */

import java.io.*;
import java.util.*;


public class Main {



    public static void main(String[] args) throws IOException {

    	//Check before giving meaning
        if (args.length < 2) System.out.println("Need more arguments. ");

    	
    	
        String inFile1 = args[0];
        String inFile2 = args[1];
        String dilateOutputFile = args[2];
        String erodeOutputFile = args[3];
        String closingOutputFile = args[4];
        String openingOutputFile = args[5];
        String PrettyPrintFile = args[6];

        //Image
        int numImgRows = 0;
        int numImgCols = 0;
        int imgMin = 0;
        int imgMax= 0;

        //Structure element
        int numStructRows = 0;
        int numStructCols = 0;
        int structMin =0;
        int structMax= 0;
        int rowOrigin = 0;
        int colOrigin = 0;

        //Arrays
        int[][] zeroFrameAry;
        int[][] morphAry;
        int[][] tempAry;
        int[][] structAry;




        
        

        //File reader
        File myInputFile1 = new File(inFile1);
        File myInputFile2 = new File(inFile2);

        //File writer
        FileWriter dilateOutputWriter = new FileWriter(dilateOutputFile);
        FileWriter erodeOutputWriter = new FileWriter(erodeOutputFile);
        FileWriter closingOutputWriter = new FileWriter(closingOutputFile);
        FileWriter openingOutputWriter = new FileWriter(openingOutputFile);
        FileWriter PrettyPrintWriter = new FileWriter(PrettyPrintFile);

        //Read into stream
        Scanner myImageReader = new Scanner(myInputFile1);
        Scanner myStructReader = new Scanner(myInputFile2);

        if(myImageReader.hasNextInt()) numImgRows = myImageReader.nextInt();
        if(myImageReader.hasNextInt()) numImgCols = myImageReader.nextInt();
        if(myImageReader.hasNextInt()) imgMin = myImageReader.nextInt();
        if(myImageReader.hasNextInt()) imgMax = myImageReader.nextInt();

        if(myStructReader.hasNextInt()) numStructRows = myStructReader.nextInt();
        if(myStructReader.hasNextInt()) numStructCols = myStructReader.nextInt();
        if(myStructReader.hasNextInt()) structMin = myStructReader.nextInt();
        if(myStructReader.hasNextInt()) structMax = myStructReader.nextInt();
        if(myStructReader.hasNextInt()) rowOrigin = myStructReader.nextInt();
        if(myStructReader.hasNextInt()) colOrigin = myStructReader.nextInt();

        //Array for Image.
        int rowFrameSize = numStructRows/2;
        int colsFrameSize = numStructCols/2;
        int extraRows = rowFrameSize*2;
        int extraCols = colsFrameSize*2;


        zeroFrameAry = new int[numImgRows + extraRows][numImgCols + extraCols];
        morphAry = new int[numImgRows + extraRows][numImgCols + extraCols];
        tempAry = new int[numImgRows + extraRows][numImgCols + extraCols];
        structAry = new int[numStructRows][numStructCols];

        MMorph mMorph;
        mMorph = new MMorph(numImgRows, numImgCols, imgMin, imgMax,
                numStructRows, numStructCols, structMin, structMax,
                rowOrigin, colOrigin, rowFrameSize, colsFrameSize,
                extraRows, extraCols, structAry);

        //zero2DAry(zeroFramedAry, numImgRows, numImgCols)
        mMorph.zero2DAry(zeroFrameAry, numImgRows, numImgCols);

        //loadImage
        mMorph.loadImage(myImageReader, zeroFrameAry);

        //prettyPrint
        PrettyPrintWriter.write("Original image [pretty printed]. \n" );
        mMorph.prettyPrint(zeroFrameAry, PrettyPrintWriter);

        //zero2DAry(structAry, numStructRows, numStructCols)
        mMorph.zero2DAry(structAry, numStructRows, numStructCols);

        //loadstruct (structFile, structAry)
        // load structFile to structAry.
        mMorph.loadstruct(myStructReader, structAry);

        //prettyPrint
        PrettyPrintWriter.write("Structuring Element [pretty printed]. \n" );
        mMorph.prettyPrint(structAry, PrettyPrintWriter);

       //Zero out array
        mMorph.zero2DAry(morphAry,numImgRows, numImgCols);

        //Dilation
        mMorph.zero2DAry(morphAry, numImgRows, numImgCols);
        mMorph.ComputeDilation(zeroFrameAry, morphAry);
        mMorph.AryToFile(morphAry, dilateOutputWriter);
        dilateOutputWriter.write("Dilation [pretty printed]. \n" );
        mMorph.prettyPrint(morphAry, dilateOutputWriter);

        //ComputeErosion
        mMorph.zero2DAry(morphAry, numImgRows, numImgCols);
        mMorph.ComputeErosion(zeroFrameAry, morphAry);
        mMorph.AryToFile(morphAry, erodeOutputWriter);
        erodeOutputWriter.write("Erosion [pretty printed]. \n" );
        mMorph.prettyPrint(morphAry, erodeOutputWriter);

        //ComputeOpening
        mMorph.zero2DAry(morphAry, numImgRows, numImgCols);
        mMorph.ComputeOpening(zeroFrameAry, morphAry, tempAry);
        mMorph.AryToFile(morphAry, openingOutputWriter);
        openingOutputWriter.write("Opening [pretty printed]. \n" );
        mMorph.prettyPrint(morphAry, openingOutputWriter);

        //ComputeClosing
        mMorph.zero2DAry(morphAry, numImgRows, numImgCols);
        mMorph.ComputeClosing(zeroFrameAry, morphAry, tempAry);
        mMorph.AryToFile(morphAry, closingOutputWriter);
        closingOutputWriter.write("Closing [pretty printed]. \n" );
        mMorph.prettyPrint(morphAry, closingOutputWriter);
    }
}