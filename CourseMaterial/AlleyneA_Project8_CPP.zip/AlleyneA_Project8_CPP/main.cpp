#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

class boundaryPt{
    friend class kCurvature;

    int x;
    int y;
    int lm;
    int corner;
    double curvature;



};
class kCurvature{
    public:
        int K;
        int numPts;
        boundaryPt* PtAry;
        double neigh[5];




        kCurvature(int k_Curvature){
            this->K = k_Curvature;
        }

    void storePt(int x, int y, int index) {
            //Store into pointer array
            PtAry[index].x = x;
            PtAry[index].y = y;
    }

    int countPts(fstream &fstream) {

        string line;
        //count the number of points in the inputFile
        while(getline(fstream,line)) {
            numPts++;
        }

        return numPts;
    }

//Begin
    void initialization(fstream &inputFile) {

             numPts = countPts(inputFile);

        PtAry = new boundaryPt [numPts];


            inputFile.flush();
            inputFile.clear();
            inputFile.seekp(14,inputFile.beg);

            int index = 0;
            while(index != numPts){
                int x;
                int y;

                inputFile >> x;
                inputFile >> y;

                storePt(x, y, index);
                index++;
            }
    }

    void printArray(ofstream &write) {
            //Display contents of array
        for (int i = 0; i < numPts; i++)
        {
            write << PtAry[i].x << " " <<  PtAry[i].y << endl;
        }
    }

    void cornerDetection(ofstream &of) {
            int Q = 0;
            int P = K;
            int R = 2 * K;


        int index = P;
        while(P != K - 1) {

            double c = computeCurvature(Q, P, R);
            PtAry[index].curvature = c;

            of << "Q:" << Q << "  P:" << P << "  R:" << R << " index:" << index << " x:" << PtAry[index].x << "  y:" <<
               PtAry[index].y << "  curvature:" << PtAry[index].curvature << endl;

            Q = (Q + 1) % numPts;
            P = (P + 1) % numPts;
            R = (R + 1) % numPts;
            index = (index + 1) % numPts;
        }


    }

    double computeCurvature(int q, int p, int r) {
            double pCurvature = 0;

            //look at the points and use K to get the next point.
            int qRow = PtAry[q].x;  //r1
            int qCol = PtAry[q].y;  //c1

            int pRow = PtAry[p].x;  //r2
            int pCol = PtAry[p].y;  //c2

            int rRow = PtAry[r].x;  //r3
            int rCol = PtAry[r].y;  //c3

            int c1_c2 = qCol - pCol;
            int r1_r2 = (qRow - pRow);


            double c2_c3 = pCol - rCol;
            double r2_r3 = pRow - rRow;

            //too many errors
            if(r2_r3 == 0 ) {
                r2_r3 = 1;
            }

            if(r1_r2 == 0) {
                r1_r2 = 1;
            }
             pCurvature = abs(((c1_c2) / (r1_r2) ) - ((c2_c3) / (r2_r3)));

        return pCurvature;
    }

    void localMaxima() {

        for  (int j = 0; j < numPts - 1; j++) {

            neigh[0] = PtAry[j - 2].curvature;
            neigh[1] = PtAry[j - 1].curvature;
            neigh[2] = PtAry[j].    curvature;
            neigh[3] = PtAry[j + 1].curvature;
            neigh[4] = PtAry[j + 2].curvature;

            double max = PtAry[j].    curvature;

//Problem here. I've debugged the entire code and the problem lives here as the array does not want to change local
            if(j == 0){
                for( int m = 2; m < 5;m++){

                    if(max >= neigh[m]){
                        PtAry[j].lm = 1;
                    }else{
                        PtAry[j].lm = 0;
                        break;
                    }
                }
            }else if(j == 1){
                for( int m = 1; m < 5;m++){
                    if(max >= neigh[m]){
                       PtAry[j].lm = 1;
                    }else{
                        PtAry[j].lm = 0;
                        break;

                    }
                }
            }else{
                for( int m = 0; m < 5;m++){
                    if(max >= neigh[m]){
                        PtAry[j].lm = 1;
                    }else{
                        PtAry[j].lm = 0;
                        break;

                    }
                }
            }
        }
    }


    void markCorner() {
        for (int i = 0; i <= numPts - 1; i++) {

            if (i == 0) {
                if (PtAry[i].lm == 1 || PtAry[i + 1].lm == 1) {
                    PtAry[i].corner = 9;
                } else {
                    PtAry[i].corner = 1;
                }
            } else {
                if ((PtAry[i].lm == 1) && (!PtAry[i + 1].lm == 1 != !PtAry[i - 1].lm == 1)) {
                    PtAry[i].corner = 9;
                } else {
                    PtAry[i].corner = 1;
                }
                // }
            }
        }
    }

    void printBoundary(ofstream &of) {
        for(int i = 0; i < numPts; i++){
            of << " x:" << PtAry[i].x  << " y:" << PtAry[i].y << " corner:" <<  PtAry[i].corner <<
            " curve:" <<  PtAry[i].curvature <<  endl;
        }
    }

    void display(int ** imageArray) {
      for(int i = 0; i < numPts; i++){
          imageArray[PtAry[i].x][PtAry[i].y] = PtAry[i].corner;

      }
    }

    void prettyPrint(ofstream &of, int r, int c, int **array) {
            for( int i = 0; i < r; i++){
                for( int j = 0; j < c; j++){
                    if(array[i][j] == 0){
                        of << ". ";
                    }else{
                        of << array[i][j] << " ";
                    }
                }
                of << endl;
            }
    }
};

int main(int argc, char *argv[]) {

    //Console arguments.
    string dataFile = argv[1];
    string outFile = argv[2];
    string outFile1 = argv[3];
    string outFile2 = argv[4];

    //InputFile values
    int numRows;
    int numCols;
    int minVal;
    int maxVal;
    int label;

    //Dynamic array for corner values
    int** imageAry;




    //User console input
    int k_Curvature;
    cout << "Please enter a K to be used in the K-curvature computation :";

    while( !(cin >> k_Curvature)){
        cin.clear();
        cin.ignore();
        cout << "K should be an number. Please enter a number." << endl;
    }

    //Obtain user input of K
    if(argc < 5)
    {
        cout << "You are missing the [K] curvature value. Please enter!" << endl;
    }

    //Open input file stream
    fstream inputFile;
    inputFile.open("data.txt");

    inputFile >> numRows >> numCols >> minVal >> maxVal >> label;


    imageAry = new int *[numRows];
    for(int row = 0; row < numRows; row++){
        imageAry[row] = new int[numCols];
    }

    for(int i = 0; i < numRows; i++){
        for(int j = 0; j < numCols; j++){
                imageAry[i][j] = 0;
        }
    }
    //Open output file stream
    ofstream outputFile_1 (outFile);
    ofstream outputFile_2 (outFile1);
    ofstream outputFile_3 (outFile2);

    //K curvature class
    kCurvature kC(k_Curvature);

    kC.initialization(inputFile);
    kC.printArray(outputFile_3);
    kC.cornerDetection(outputFile_3);
    kC.localMaxima();
    kC.markCorner();
    kC.printBoundary(outputFile_1);
    kC.display(imageAry);
    kC.prettyPrint(outputFile_2, numRows, numCols,imageAry);

    inputFile.close();
    outputFile_1.close();
    outputFile_2.close();
    outputFile_3.close();
    return 0;
}
